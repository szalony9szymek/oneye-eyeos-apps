There are 2 eyepackage files in this zip
eyeFW.eyepackage is the software that links th FW FLV Player in to eyeos and is licensed under the aGPL same as eyeOS.
FW_FLV_PLAYER_FOR_eyeFW.eyepackage is the Player for eyeFW and is made by Jeroen Wijering and is licensed under the creative commons by-nc-sa
http://creativecommons.org/licenses/by-nc-sa/3.0/
http://www.longtailvideo.com/players/jw-flv-player/

You must install both files for eyeFW to work.
Files seperated to stay away from legal stuff.